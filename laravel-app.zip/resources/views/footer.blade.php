  <footer>
      <div class="row">
          <a href="{{route('privacy')}}">privacy policy</a>
          <a href="{{route('cookie')}}">cookies policy</a>
          <h4 class="not-link"><i class="fa-regular fa-copyright"></i>talantatrust<span id="currentYear"></span></h4>
          {{-- <a class="not-link" href="#"><i class="fa-regular fa-copyright"></i>talantatrust<span id="currentYear"></span></a> --}}
      </div>
  </footer>
