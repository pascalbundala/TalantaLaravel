<h3>New Contact Message</h3>
<p><strong>FistName:</strong> {{ $data['firstname'] }}</p>
<p><strong>LastName:</strong> {{ $data['lastname'] }}</p>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Phone Number:</strong> {{ $data['phone'] }}</p>
<p><strong>Message:</strong> {{ $data['message'] }}</p>
