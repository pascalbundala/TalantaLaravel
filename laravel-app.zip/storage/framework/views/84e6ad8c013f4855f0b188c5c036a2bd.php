<h3>New Contact Message</h3>
<p><strong>FistName:</strong> <?php echo e($data['firstname']); ?></p>
<p><strong>LastName:</strong> <?php echo e($data['lastname']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Phone Number:</strong> <?php echo e($data['phone']); ?></p>
<p><strong>Message:</strong> <?php echo e($data['message']); ?></p>
<?php /**PATH /home/p/Desktop/PROJECT/Talanta/TalantaWebsite/resources/views/emails/contactus.blade.php ENDPATH**/ ?>