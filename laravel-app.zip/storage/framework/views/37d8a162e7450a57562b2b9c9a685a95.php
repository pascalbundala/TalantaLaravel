  <footer>
      <div class="row">
          <a href="<?php echo e(route('privacy')); ?>">privacy policy</a>
          <a href="<?php echo e(route('cookie')); ?>">cookies policy</a>
          <h4 class="not-link"><i class="fa-regular fa-copyright"></i>talantatrust<span id="currentYear"></span></h4>
          
      </div>
  </footer>
<?php /**PATH /home/p/Desktop/PROJECT/Talanta/TalantaWebsite/resources/views/footer.blade.php ENDPATH**/ ?>